package com.example.rentacar.service;

import com.example.rentacar.demoapplication.model.Student;


public interface StudentService {
	
	Student save(Student student);

}
